// function randomInteger(min, max) {
//     return Math.floor(Math.random() * (max - min + 1)) + min;
// }

// function randColor() {
//     var r = randomInteger(0, 255);
//     var g = randomInteger(0, 255);
//     var b = randomInteger(0, 255);
//     return 'rgb(' + r + ', ' + g + ', ' + b + ')'
// }

// console.log(randColor())

// (function(){
//     console.log('test')
// })();

// hoisting - хоистинг - поднятие

// var a;
// a = 3;
// var b = 6;

// 1. созданте переменной
// 2. присваивание значение переменной
// 3. функции

// d();

// function d() {
//     console.log('d');
// }

// var e = function() {
//     console.log('e');
// }

// e();

// стрелочные функции

// var arrowF = (text) => {
//     console.log(text)
// }

// arrowF('стрелочная функция');

// function hoist() {
//     a = 20;
//     var b = 100;
// }

// hoist();

// console.log(a);

// GDPR

// 0, false, '', undefinded, NaN - это всегда ложные значения

// var checkShowGdpBanner = () => {
//     var location = '';
//     // '' === false

//     if (!location) {
//         return true;
//     }

//     if (location !== 'eu') {
//         return false;
//     }

//     return location;

// }

// var showGdprBanner = () => {
//     // 1. узнать нужно ли показать баннер
//     // 2. отправить country code в БД
//     if (checkShowGdpBanner()) {
//         console.log('показать баннер для ' + checkShowGdpBanner());
//     }
//     else {
//         console.log('баннер можно не показывать для страны ' + checkShowGdpBanner())
//     }
// }

// showGdprBanner();

// Рекурсия
// когда мы вызываем функцию внутри этой же функции

// 2 подхода

// 1 подход

// var result = 1;

// function pow(x, n) {
    
//     // умножаем result na x n раз в цикле
//     for (var i = 0; i < n; i++) {
//         result *= x;
//     }
//     return result;
// }

// console.log(pow(2,3))

// function powR(x, n) {
//     if (n === 1) {
//         return x;
//     } 
//     else {
//         return x * powR(x, n - 1);
//     }
// }
// console.log(powR(2,3))

// рекурсия = безопасность

// var arr = [
//     {
//         name: 'Вася',
//         password: 123,
//     },
//     {
//         name: 'Женя',
//         password: 345,
//     }
// ]

// console.log(arr[1]);

// function checkPassword(pass, name) {
//     for (var i = 0; i < arr.length; i++) {
//         if (arr[i].password === pass && arr[i].name === name) {
//             console.log('авторизоваться');
//             return;
//         }        
//     }
//     console.log('Введите пароль еще раз')

// }

// var userName = prompt('Введите имя')
// var userPassword = +prompt('Введите пароль')

// checkPassword(userPassword, userName);

// Замыкание
// комбинация функции и лексического окружения, в котором эта функция была выполнена


// var z = function (x) {
//     console.log(x);
//     return function(y) {
//         return x + y;
//     }
// }

// var sum = z(2);

// console.log(sum(3));

// this

// массив который будет включать несколько объектов с именами разных сотрудников

var arrWorkersList = [
    {
        name: 'Вася',
        skills: 'javascript',
        expierence: 5,
        age: 25,
        options: showOptions(this.name, this.birthDate)
    },
    {
        name: 'Вася',
        skills: 'javascript',
        expierence: 5,
        age: 21,
        options: showOptions(this.name, this.birthDate)
    },
]

// посчитать общий возраст сотрудников из масива с объектами

var arrWorker = {
        name: 'Вася',
        skills: 'javascript',
        expierence: 5,
        birthDate: 1995
}

function showOptions() {
    return `Имя: ${this.name}. Дата рождения ${this.birthDate}`
}

var optionsFromObj = showOptions.bind(arrWorker);
console.log(optionsFromObj())

function checkAge() {
    return this.age
}

var ageSum;

for (var i = 0; i < arrWorkersList.length; i++) {
    var workerAge = checkAge.bind(arrWorkersList[i]);
    ageSum = workerAge();
    ageSum =+ ageSum;
}

console.log(ageSum);

// console.log(arrWorkersList.options())

// this - window
